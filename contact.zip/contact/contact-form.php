<?php
    $name = $_POST["Email"];
    $email = $_POST["Password"];
    $conn = mysqli_connect("localhost", "root", "root@123", "contact_application") or die("Connection Error: " . mysqli_error($conn));
    mysqli_query($conn, "SELECT  name,password,id FROM userInformation WHERE name = $name");
    $result = $conn->mysqli_query->excute();
    if($result['name'] == $name && $result['password'] == $password) {
    	echo "Login Successfully";
    }
?>
<!DOCTYPE html>
<html>
<head>
	<title>Contact Form and Contact List Page</title>
</head>
<body>
<form action="contact-save.php" method="post" name="sign-in-validation">
	<input type="text" name="Name" value="">
	<input type="text" name="Phone Number" value="">
	<input type="text" name="Email" value="">
	<input type="submit" name="Save" value="Save">
</form>
<table>
	<tr>
		<th>Name</th>
		<th>Ph no</th>
		<th>Email</th>
	</tr>
<?php
	$conn = mysqli_connect("localhost", "root", "root@123", "contact_application") or die("Connection Error: " . mysqli_error($conn));
	mysqli_query($conn, "SELECT  name,Phonenumber,email FROM userInformation WHERE id = $id");
	$result = $conn->mysqli_query->excute();
	foreach ($result as $key => $value) {
		echo '<tr><th>'. $value[$key]['name'].'</th></tr>';
	}
?>
</table>
</body>
</html>