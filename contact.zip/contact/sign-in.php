<?php
    $name = $_POST["Email"];
    $email = $_POST["Password"];
    $secret = $_POST["secret"];
    $conn = mysqli_connect("localhost", "root", "root@123", "contact_application") or die("Connection Error: " . mysqli_error($conn));
    mysqli_query($conn, "INSERT INTO userInformation (name, password,secret) VALUES ('" . $name. "', '" . $email. "','" . $secret. "')");
    $insert_id = mysqli_insert_id($conn);
    echo "Account created Successfully.";
?>
<!DOCTYPE html>
<html>
<head>
	<title>Sign In</title>
</head>
<body>
<form action="" method="post" name="sign-in-validation">
	<input type="text" name="Email" value="">
	<input type="password" name="Password" value="">
	<input type="submit" name="Sign in" value="Sign in">
</form>
</body>
</html>